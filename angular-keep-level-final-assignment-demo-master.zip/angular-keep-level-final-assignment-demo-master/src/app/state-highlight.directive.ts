import { Directive, Input, ElementRef, OnInit } from '@angular/core';

@Directive({
  selector: '[appStateHighlight]'
})
export class StateHighlightDirective implements OnInit {

  @Input() appStateHighlight: string;

  constructor(private el: ElementRef) {
  }

  ngOnInit() {
    if (this.appStateHighlight === 'not-started') {
      this.el.nativeElement.style.backgroundColor = 'red';
    }
    if (this.appStateHighlight === 'started') {
      this.el.nativeElement.style.backgroundColor = 'yellow';
    }
    if (this.appStateHighlight === 'completed') {
      this.el.nativeElement.style.backgroundColor = 'green';
    }
  }

}
