import { Component, Input, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';
import { AuthenticationService } from '../services/authentication.service';
import { AppComponent } from '../app.component';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit  {
  isMenuOpened:boolean = false;
  isNoteView = true;
  @Input() sidenav: AppComponent;
  constructor(private router: RouterService, private authService: AuthenticationService) { }

  ngOnInit() {
    
  }
  // For List View navigation
  routeToListView() {
    this.router.routeToListView();
    this.isNoteView = false;
  }
  // For Note View navigation
  routeToNoteView() {
    this.router.routeToNoteView();
    this.isNoteView = true;
  }

  showLogout() {
    let token = this.authService.getBearerToken();
    if (token !== undefined && token !== '' && token !== null) {
        return true;
    }
    return false;
  }

  logout() {
    window.localStorage.clear();
    this.sidenav.toggle();
    this.router.routeToLogin();
  }

  menuToggle() {
    this.sidenav.toggle();
  }
}
