// Category property values
export class Category {
    id: String;
    categoryName: String;
    categoryDescription: String;
    categoryCreatedBy: String;
    categoryCreationDate: Date;
    categoryId: String;

}
