// Reminder property values
export class Reminder {
    id: String;
    reminderName: String;
    reminderDescription: String;
    reminderType: String;
    reminderCreatedBy: String;
    reminderCreationDate: Date;
    reminderId: String;
  }
